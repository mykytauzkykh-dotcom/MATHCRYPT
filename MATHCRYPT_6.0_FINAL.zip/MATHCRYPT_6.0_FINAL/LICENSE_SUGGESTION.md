# License suggestion (NOT installed)

No `LICENSE` file has been added: choosing a license is the author's decision. Options for an educational/research project:

* **MIT** — very permissive, short; others may reuse the code in closed products. Good for maximum adoption.
* **Apache-2.0** — permissive plus an explicit patent grant and NOTICE requirement.
* **GPL-3.0-or-later** — copyleft: derivative works must stay open source.
* **CC BY 4.0** — suitable for the *documentation and texts* (not recommended for code).

A common choice for this kind of project: **MIT for code + CC BY 4.0 for documentation**. When you decide, add the license text as `LICENSE`, set `license:` in `CITATION.cff`, and add a notice in `index.html`'s footer. Third-party notes: the optional three.js script and Google Fonts stylesheet are loaded from CDNs only if online and have their own licenses; the program works without them.
