# Changelog
## 6.0 Final
* Reproducibility packages (ZIP: data, CSV/JSON, parameters, seed, version, methodology, charts, SHA-256 sums, instructions); import, validation and re-run.
* Reports: large tables are split across A4 pages (header repeated), optional full data set in the appendix (≤ 3000 rows), verified with a real PDF.
* Security: whitelist SVG sanitiser (import + render), sanitised dashboard counters; resource limits for Pell, binomial, Fibonacci, LLL.
* Open-science documents (README EN/UK, CITATION.cff template, CONTRIBUTING, SECURITY, ARCHITECTURE, algorithms, user guide, reproduction guide, license suggestion).
* Tests 170 → 242.
## 6.0 Stage 3c
Dashboard, knowledge graph, defence mode 2.0, PWA.
## 6.0 Stage 3b
Advanced statistics, quantum lab, post-quantum lab.
## 6.0 Stage 3a
Advanced Diophantine laboratory, A4 report generator, publications centre, backups.
## 6.0 Stages 1–2 / 5.0
See `docs/history/`.
