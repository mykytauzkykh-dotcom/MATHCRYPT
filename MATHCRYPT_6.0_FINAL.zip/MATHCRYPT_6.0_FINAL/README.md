# MATHCRYPT 6.0

A single-file, offline-capable educational and research platform for **number theory and cryptography**, centred on Diophantine equations and the Euclidean algorithm. It runs entirely in the browser (no server, no tracking). The interface is available in Ukrainian and English.

> **Status:** research / educational software. Cryptographic demonstrations are *toy implementations* and must **not** be used to protect real data.

## Features

| Area | What is implemented |
|---|---|
| Diophantine equations | Linear `ax+by=c`, ≥3 variables, systems over ℤ (Smith / Hermite normal forms, verified by substitution), congruence systems, bounded integer optimisation, Pell equations, bounded search for non-linear equations (clearly distinguished from proofs of non-existence) |
| Number theory | Euclid (steps, extended), continued fractions, CRT, φ / μ / τ / σ, Miller–Rabin, factorisation, modular arithmetic, proofs centre |
| Cryptography lab | Textbook RSA, Diffie–Hellman, elliptic curves, SHA-256/512, classical ciphers |
| Lattices | Gauss reduction, LLL (exact integer/rational arithmetic) |
| Quantum lab | Classical state-vector simulator: Bloch sphere, X/Y/Z/H/S/T/CNOT, circuits, entanglement, QFT, Grover, Shor order finding |
| Post-quantum lab | LWE, Module-LWE, ML-KEM NTT (q = 3329), Lamport hash signature, size tables; theory of ML-KEM / ML-DSA / SLH-DSA |
| Statistics | Descriptive tests, Shapiro–Wilk, Mann–Whitney, Wilcoxon, Kruskal–Wallis, ANOVA, bootstrap (percentile/BCa), OLS / polynomial / Huber regression, power analysis |
| Experiments | Six automated, seeded, reproducible experiments (A–F) run in a Web Worker |
| Research tools | Notebook (IndexedDB), archive, publications centre (BibTeX / RIS / JSON), A4 scientific reports, reproducibility packages, backups |
| Knowledge graph, dashboard, 7-minute defence mode, PWA | See `docs/USER_GUIDE.md` |

## Quick start

* **From disk:** open `offline/mathcrypt.html` (or `site/index.html`) in a modern browser. No internet is needed.
* **On the web:** upload the whole `site/` folder (5 files) to any static host (e.g. Netlify Drop). See `docs/NETLIFY.md`.
* **Tests:** open the tab *Automatic tests* and press the run button, or run `node tests/t5.js site/index.html` (needs Playwright).

## Honest verification status

See `docs/TEST_REPORT.md`. Short version: the built-in suite passes in **Chromium only**; Firefox and WebKit were not available in the development environment and are **untested**.

## Reproducibility

Every experiment is deterministic for a given seed and program version. Export a package (ZIP with data, CSV/JSON, parameters, seed, version, SHA-256 checksums, instructions), import it later and re-run it. See `docs/REPRODUCTION.md`.

## Citation

See `CITATION.cff`. The author fields are intentionally placeholders — fill them in. No DOI exists unless you create one (e.g. via Zenodo); none is invented here.

## License

No license is installed. See `LICENSE_SUGGESTION.md`; the author must choose.
